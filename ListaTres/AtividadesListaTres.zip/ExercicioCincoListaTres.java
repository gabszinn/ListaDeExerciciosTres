public class ExercicioCincoListaTres {
    public static void main(String[] args) {
             int numeroImpar = 1; 
        System.out.println("Números ímpares entre 1 e 50:");


        while (numeroImpar <= 50) {
            System.out.println(numeroImpar);
            numeroImpar += 2;

        }
    }
}
